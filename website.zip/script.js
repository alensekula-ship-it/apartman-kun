function moveGallery(direction){const slider=document.getElementById('gallerySlider');if(!slider)return;const amount=Math.min(360,slider.clientWidth*0.75);slider.scrollBy({left:direction*amount,behavior:'smooth'});}

const galleryPhotos = [
  {src:'photo_01.jpg', alt:'Dnevni boravak i kuhinja'},
  {src:'photo_02.jpg', alt:'Blagovaonica'},
  {src:'photo_03.jpg', alt:'Dnevni boravak'},
  {src:'photo_04.jpg', alt:'Spavaća soba'},
  {src:'photo_05.jpg', alt:'Spavaća soba'},
  {src:'photo_06.jpg', alt:'Kupaona'},
  {src:'photo_07.jpg', alt:'Hodnik'}
];

let currentLightboxIndex = 0;
let lightboxTouchStartX = 0;

function openLightbox(index){
  currentLightboxIndex = (index + galleryPhotos.length) % galleryPhotos.length;
  const box = document.getElementById('galleryLightbox');
  const img = document.getElementById('lightboxImage');
  if(!box || !img) return;
  img.src = galleryPhotos[currentLightboxIndex].src;
  img.alt = galleryPhotos[currentLightboxIndex].alt;
  box.classList.add('open');
  box.setAttribute('aria-hidden','false');
  document.body.style.overflow = 'hidden';
}

function closeLightbox(){
  const box = document.getElementById('galleryLightbox');
  if(!box) return;
  box.classList.remove('open');
  box.setAttribute('aria-hidden','true');
  document.body.style.overflow = '';
}

function changeLightbox(direction){
  openLightbox(currentLightboxIndex + direction);
}

document.addEventListener('keydown', function(e){
  const box = document.getElementById('galleryLightbox');
  if(!box || !box.classList.contains('open')) return;
  if(e.key === 'Escape') closeLightbox();
  if(e.key === 'ArrowLeft') changeLightbox(-1);
  if(e.key === 'ArrowRight') changeLightbox(1);
});

document.addEventListener('DOMContentLoaded', function(){
  const box = document.getElementById('galleryLightbox');
  if(!box) return;
  box.addEventListener('click', function(e){
    if(e.target === box) closeLightbox();
  });
  box.addEventListener('touchstart', function(e){
    lightboxTouchStartX = e.changedTouches[0].clientX;
  }, {passive:true});
  box.addEventListener('touchend', function(e){
    const dx = e.changedTouches[0].clientX - lightboxTouchStartX;
    if(Math.abs(dx) > 45) changeLightbox(dx > 0 ? -1 : 1);
  }, {passive:true});
});

const ICS_URLS = [
  "https://ical.booking.com/v1/export?t=b16bd93c-67f9-4d88-a2f4-e8dd126222c3",
  "https://www.airbnb.com/calendar/ical/1459695479210761422.ics?t=8b0f0e57d5cc465aaeb4612c86071e1f&locale=hr"
];
let currentDate = new Date();
let occupiedDates = new Set();

function pad2(n) {
  return String(n).padStart(2, '0');
}

function dateKey(date) {
  return date.getFullYear() + '-' + pad2(date.getMonth() + 1) + '-' + pad2(date.getDate());
}

function parseIcsDate(value) {
  const s = String(value || '').trim().slice(0, 8);
  const y = Number(s.slice(0, 4));
  const m = Number(s.slice(4, 6)) - 1;
  const d = Number(s.slice(6, 8));
  if (!y || Number.isNaN(m) || !d) return null;
  return new Date(y, m, d);
}

function addRange(start, endExclusive) {
  const cur = new Date(start.getFullYear(), start.getMonth(), start.getDate());
  const end = new Date(endExclusive.getFullYear(), endExclusive.getMonth(), endExclusive.getDate());
  while (cur < end) {
    occupiedDates.add(dateKey(cur));
    cur.setDate(cur.getDate() + 1);
  }
}

function parseIcs(text) {
  const clean = String(text || '').replace(/\r?\n[ \t]/g, '');
  const events = clean.split('BEGIN:VEVENT').slice(1);
  for (const ev of events) {
    const startMatch = ev.match(/DTSTART(?:;[^:\r\n]*)?:(\d{8})/);
    const endMatch = ev.match(/DTEND(?:;[^:\r\n]*)?:(\d{8})/);
    if (!startMatch || !endMatch) continue;
    const start = parseIcsDate(startMatch[1]);
    const end = parseIcsDate(endMatch[1]);
    if (start && end) addRange(start, end);
  }
}

function renderCalendar() {
  const title = document.getElementById('calendarTitle');
  const days = document.getElementById('calendarDays');
  if (!title || !days) return;

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const names = ['Siječanj','Veljača','Ožujak','Travanj','Svibanj','Lipanj','Srpanj','Kolovoz','Rujan','Listopad','Studeni','Prosinac'];

  title.textContent = names[month] + ' ' + year;
  days.innerHTML = '';

  const first = new Date(year, month, 1);
  const last = new Date(year, month + 1, 0);
  let start = first.getDay();
  start = start === 0 ? 6 : start - 1;

  for (let i = 0; i < start; i++) {
    const e = document.createElement('span');
    e.className = 'muted';
    days.appendChild(e);
  }

  const today = new Date();
  for (let d = 1; d <= last.getDate(); d++) {
    const date = new Date(year, month, d);
    const cell = document.createElement('span');
    cell.textContent = d;

    const classes = [];
    if (d === today.getDate() && month === today.getMonth() && year === today.getFullYear()) classes.push('today');
    if (occupiedDates.has(dateKey(date))) classes.push('busy');
    if (classes.length) cell.className = classes.join(' ');

    days.appendChild(cell);
  }
}

function changeMonth(delta) {
  currentDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + delta, 1);
  renderCalendar();
}

async function loadBusyJson() {
  const res = await fetch('busy-dates.json?v=' + Date.now(), { cache: 'no-store' });
  if (!res.ok) throw new Error('Nema lokalne datoteke.');
  const data = await res.json();
  const dates = Array.isArray(data) ? data : (data.busy || data.dates || []);
  dates.forEach(x => occupiedDates.add(String(x).slice(0, 10)));
  return dates.length;
}

async function loadIcsFallback() {
  let lastError = null;

  for (const ICS_URL of ICS_URLS) {
    const urls = [
      'https://api.allorigins.win/raw?url=' + encodeURIComponent(ICS_URL),
      'https://corsproxy.io/?' + encodeURIComponent(ICS_URL),
      'https://cors.isomorphic-git.org/' + ICS_URL,
      'https://api.codetabs.com/v1/proxy/?quest=' + encodeURIComponent(ICS_URL)
    ];

    for (const url of urls) {
    try {
      const res = await fetch(url, { cache: 'no-store' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const text = await res.text();
      if (text.includes('BEGIN:VCALENDAR') || text.includes('BEGIN:VEVENT')) {
        parseIcs(text);
        return occupiedDates.size;
      }
    } catch (e) {
      lastError = e;
    }
    }
  }

  if (occupiedDates.size > 0) return occupiedDates.size;
  throw lastError || new Error('Kalendar se ne može učitati.');
}

async function loadAvailabilityCalendar() {
  const status = document.getElementById('calendarStatus');
  renderCalendar();

  try {
    if (status) status.textContent = 'Učitavam kalendar...';

    try {
      await loadBusyJson();
    } catch (e) {
      await loadIcsFallback();
    }

    renderCalendar();

    if (status) {
      status.textContent = occupiedDates.size
        ? 'Crveno označeni datumi su zauzeti.'
        : 'Kalendar je učitan. Trenutno nema označenih zauzetih datuma.';
    }
  } catch (e) {
    console.error(e);
    if (status) status.textContent = 'Kalendar se trenutno ne može automatski učitati. Pošalji WhatsApp upit za provjeru termina.';
  }
}

document.addEventListener('DOMContentLoaded', loadAvailabilityCalendar);
